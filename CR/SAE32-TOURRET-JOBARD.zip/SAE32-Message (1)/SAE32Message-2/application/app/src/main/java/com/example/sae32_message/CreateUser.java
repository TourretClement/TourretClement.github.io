package com.example.sae32_message;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CreateUser extends AppCompatActivity {

    TextInputEditText textUsername;
    EditText textPassword;
    Button buttonCreate;
    Button buttonBack;

    FirebaseDatabase database = FirebaseDatabase.getInstance("https://sae32-6c286-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference usersDbRef = database.getReference().child("Users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_user);

        textUsername = findViewById(R.id.textInputEditText);
        textPassword = findViewById(R.id.editTextTextPassword);
        buttonCreate = findViewById(R.id.Create);
        buttonBack = findViewById(R.id.buttonBack);


        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertUserData();
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateUser.this, MainActivity.class);
                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
    public void insertUserData(){
        String Username = textUsername.getText().toString();
        String Password = textPassword.getText().toString();
        Users users = new Users(Username,Password);

        // Vérifier si les champs sont vides
        if (Username.isEmpty() || Password.isEmpty()) {
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return; // Arrêter l'exécution si un champ est vide
        }
        usersDbRef.orderByChild("username").equalTo(Username).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Le nom d'utilisateur existe déjà
                    Toast.makeText(CreateUser.this, "Nom d'utilisateur déjà pris", Toast.LENGTH_SHORT).show();
                } else {
                    usersDbRef.push().setValue(users);
                    Toast.makeText(CreateUser.this, "Utilisateur créé !", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(CreateUser.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(CreateUser.this, "Erreur : " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }}