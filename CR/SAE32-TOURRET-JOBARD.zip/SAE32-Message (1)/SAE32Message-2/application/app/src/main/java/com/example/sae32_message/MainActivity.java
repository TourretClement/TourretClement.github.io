package com.example.sae32_message;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    TextInputEditText textUsername;
    EditText textPassword;
    Button buttonLogin;
    Button buttonNewUser;

    FirebaseDatabase database = FirebaseDatabase.getInstance("https://sae32-6c286-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference usersDbRef = database.getReference().child("Users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        buttonNewUser = findViewById(R.id.newUser);

        buttonNewUser.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, CreateUser.class);
            startActivity(intent);
        });

        buttonLogin = findViewById(R.id.Login);
        buttonLogin.setOnClickListener(view -> verifyUserCredentials());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void verifyUserCredentials() {
        textUsername = findViewById(R.id.textInputEditText);
        textPassword = findViewById(R.id.editTextTextPassword);
        String inputUsername = textUsername.getText().toString().trim();
        String inputPassword = textPassword.getText().toString().trim();

        if (inputUsername.isEmpty() || inputPassword.isEmpty()) {
            Toast.makeText(MainActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        // Recherche de l'utilisateur dans la base de données
        usersDbRef.orderByChild("username").equalTo(inputUsername).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String dbPassword = userSnapshot.child("password").getValue(String.class);
                        if (dbPassword != null && dbPassword.equals(inputPassword)) {
                            // Connexion réussie
                            Toast.makeText(MainActivity.this, "Connexion réussie", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, PageMessage.class);
                            intent.putExtra("USERNAME", inputUsername);
                            startActivity(intent);
                            finish();
                            return;
                        }
                    }
                    Toast.makeText(MainActivity.this, "Mot de passe incorrect", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Nom d'utilisateur introuvable", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Erreur : " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
