package com.example.sae32_message;

public class Messages {
    private String message;
    private String username;
    private long timestamp; // Stockage de l'heure en millisecondes

    // Constructeur par défaut requis pour Firebase
    public Messages() {
    }

    public Messages(String message, String username) {
        this.message = message;
        this.username = username;
        this.timestamp = System.currentTimeMillis(); // Initialiser avec l'heure actuelle
    }

    public String getMessage() {
        return message;
    }

    public String getUsername() {
        return username;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
