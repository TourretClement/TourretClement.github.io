package com.example.sae32_message;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PageMessage extends AppCompatActivity {

    TextView fluxMessage;
    EditText nouveauMessage;
    Button buttonDeconnection, buttonEnvoyer;

    FirebaseDatabase database = FirebaseDatabase.getInstance("https://sae32-6c286-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference messagesDbRef = database.getReference("Messages");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_page_message);

        // Récupérer le nom d'utilisateur depuis l'Intent
        String username = getIntent().getStringExtra("USERNAME");
        if (username == null || username.isEmpty()) {
            Toast.makeText(this, "Erreur : Nom d'utilisateur non fourni", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        buttonDeconnection = findViewById(R.id.Deconnection);
        buttonEnvoyer = findViewById(R.id.Envoyer);
        fluxMessage = findViewById(R.id.textView2);
        nouveauMessage = findViewById(R.id.editTextText);

        buttonDeconnection.setOnClickListener(view -> {
            Intent intent = new Intent(PageMessage.this, MainActivity.class);
            startActivity(intent);
        });

        buttonEnvoyer.setOnClickListener(view -> envoyerMessage(username));

        // Charger les messages existants et écouter les nouveaux
        chargerMessages();

        // Gestion des insets pour les barres système
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void chargerMessages() {
        messagesDbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                StringBuilder messagesBuilder = new StringBuilder();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Messages messageObj = snapshot.getValue(Messages.class);

                    if (messageObj != null) {
                        // Convertir le timestamp en une date lisible
                        String formattedDate = dateFormat.format(new Date(messageObj.getTimestamp()));

                        messagesBuilder.append("[")
                                .append(formattedDate)
                                .append("] ")
                                .append(messageObj.getUsername())
                                .append(" : ")
                                .append(messageObj.getMessage())
                                .append("\n");
                    }
                }

                // Afficher tous les messages dans le TextView
                fluxMessage.setText(messagesBuilder.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(PageMessage.this, "Erreur de chargement des messages : " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void envoyerMessage(String username) {
        String message = nouveauMessage.getText().toString().trim();

        if (!message.isEmpty()) {
            String messageId = messagesDbRef.push().getKey();

            if (messageId != null) {
                Messages messageObj = new Messages(message, username);

                messagesDbRef.child(messageId).setValue(messageObj, (databaseError, databaseReference) -> {
                    if (databaseError != null) {
                        Toast.makeText(PageMessage.this, "Erreur : " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PageMessage.this, "Message envoyé avec succès !", Toast.LENGTH_SHORT).show();
                        nouveauMessage.setText("");
                    }
                });
            } else {
                Toast.makeText(this, "Erreur lors de la génération de l'ID du message.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Veuillez écrire un message avant d'envoyer.", Toast.LENGTH_SHORT).show();
        }
    }
}
