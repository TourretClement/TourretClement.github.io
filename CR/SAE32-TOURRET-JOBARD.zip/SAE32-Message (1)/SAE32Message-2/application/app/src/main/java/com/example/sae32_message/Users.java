package com.example.sae32_message;

public class Users {
    String Username;
    String Password;

    public Users(String username, String password) {
        Username = username;
        Password = password;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }
}
