const Ticket = require('../models/ticket');

exports.createTicket = (req, res, next) => {
    delete req.body._id;
    const ticket = new Ticket({
      ...req.body
    });
    ticket.save()
      .then(() => res.status(201).json({ message: 'Objet enregistré !'}))
      .catch(error => res.status(400).json({ error }));
};

exports.getOneTicket = (req, res, next) => {
  Ticket.findOne({ _id: req.params.id })
    .then(ticket => res.status(200).json(ticket))
    .catch(error => res.status(404).json({ error }));
};

exports.modifyTicket = (req, res, next) => {
  Ticket.updateOne({ _id: req.params.id }, { ...req.body, _id: req.params.id })
    .then(() => res.status(200).json({ message: 'Objet modifié !'}))
    .catch(error => res.status(400).json({ error }));
};

exports.deleteTicket = (req, res, next) => {
  Ticket.deleteOne({ _id: req.params.id })
    .then(() => res.status(200).json({ message: 'Objet supprimé !'}))
    .catch(error => res.status(400).json({ error }));
};

exports.getAllTicket = (req, res, next) => {
  Ticket.find()
  .then(tickets => res.status(200).json(tickets))
  .catch(error => res.status(400).json({ error }));
};