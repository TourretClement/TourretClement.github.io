const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');

const TicketCtrl = require('../controllers/ticket');

router.post('/', auth, TicketCtrl.createTicket);

router.get('/:id', auth, TicketCtrl.getOneTicket);

router.put('/:id', auth, TicketCtrl.modifyTicket);

router.delete('/:id', auth, TicketCtrl.deleteTicket);
   
router.get('/', auth, TicketCtrl.getAllTicket);

module.exports = router;